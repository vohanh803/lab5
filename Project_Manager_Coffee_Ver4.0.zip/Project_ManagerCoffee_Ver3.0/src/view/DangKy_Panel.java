package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class DangKy_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public DangKy_Panel() {
		
		JLabel lblHi = new JLabel("ĐĂng Ký");
		add(lblHi);

	}

}
