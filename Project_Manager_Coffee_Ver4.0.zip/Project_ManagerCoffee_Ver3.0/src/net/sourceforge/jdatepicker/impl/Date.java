package net.sourceforge.jdatepicker.impl;

import javax.swing.JFrame;

public class Date {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		 f.setDefaultCloseOperation(3);
		 f.setSize(555, 111);
		 f.setLocationRelativeTo(null);
		 UtilDateModel model = new UtilDateModel();
		 JDatePanelImpl datePanel = new JDatePanelImpl(model);
		 JDatePickerImpl datePicker = new JDatePickerImpl(datePanel);

		 f.add(datePicker);
		 f.setVisible(true);
	}
}
