package controller;

import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

public abstract class Action implements ActionListener, KeyListener,
		MouseListener {

}
