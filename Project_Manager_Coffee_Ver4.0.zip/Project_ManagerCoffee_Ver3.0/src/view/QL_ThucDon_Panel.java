package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class QL_ThucDon_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public QL_ThucDon_Panel() {
		
		JLabel lblThcn = new JLabel("Thực Đơn");
		add(lblThcn);

	}

}
