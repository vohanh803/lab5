package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class DoiMatKhau_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public DoiMatKhau_Panel() {
		
		JLabel lbliMtKhu = new JLabel("Đổi Mật Khẩu");
		add(lbliMtKhu);

	}

}
