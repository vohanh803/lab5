package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Properties;

import javax.swing.JOptionPane;

public class ConnectDB {

	public static Connection taoKetNoiKieu1() throws SQLException {
		// day la dong de khai bao ket noi database voi username va pass
		String dbURL = "jdbc:postgresql:detai_tkhdt?user=postgres&password=123456";
		Connection conn = DriverManager.getConnection(dbURL);
		if (conn != null) {
			// JOptionPane.showMessageDialog(null, "kết nối thành công");
			// kết nối thành công!! connect successfully
		}
		return conn;
	}

	public static Connection taoKetNoiKieu2() throws SQLException {
		// ten database can ket noi
		String dbURL = "jdbc:postgresql://localhost/detai_tkhdt";
		// sau localhost se la ten database
		String user = "postgres"; // ten nguoi dung de dang nhap vao data base
		String pass = "123456"; // mat khau
		Connection conn = DriverManager.getConnection(dbURL, user, pass);
		// tao ra ket noi

		return conn;
	}

	public static Connection taoKetNoiKieu3() throws SQLException {
		String dbURL = "jdbc:postgresql://localhost:5432/detai_tkhdt";
		Properties parameters = new Properties();
		parameters.put("user", "postgres");
		parameters.put("password", "123456");
		Connection conn = DriverManager.getConnection(dbURL, parameters);
		return conn;

	}

	// day la dong de khai bao ket noi database voi username va pass
	public boolean openConnetion() throws SQLException {
		String dbURL = "jdbc:postgresql:detai_tkhdt?user=postgres&password=123456";
		Connection conn = DriverManager.getConnection(dbURL);
		if (conn != null) {
			JOptionPane.showMessageDialog(null, "Connect Successfully");
			return true;
		}
		return false;
	}

	public static Connection getConnection() {
		String url = "jdbc:mysql://localhost/project_tkhdt";
		String user = "root";
		String psw = "";
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, psw);
		} catch (Exception e) {
			System.out.println("+ Kết nối database thất bại!");
		}
		System.out.println("+ Connect đến Database Thành Công!.");
		return con;
	}

	public static void disConnect() {
		Connection conn = null;
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		try {
			ConnectDB obj = new ConnectDB();
			// obj.taoKetNoiKieu3();
			obj.openConnetion();
			obj.getConnection();
			System.out.println("+ Connect with Database Complete!!!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}