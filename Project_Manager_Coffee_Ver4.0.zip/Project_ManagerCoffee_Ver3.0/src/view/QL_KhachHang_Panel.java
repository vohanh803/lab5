package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class QL_KhachHang_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public QL_KhachHang_Panel() {
		
		JLabel lblKhchHng = new JLabel("Khách Hàng");
		add(lblKhchHng);

	}

}
