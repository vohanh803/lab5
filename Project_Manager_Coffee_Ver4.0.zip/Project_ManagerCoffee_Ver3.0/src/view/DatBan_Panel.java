package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class DatBan_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public DatBan_Panel() {
		
		JLabel lbltBn = new JLabel("Đặt Bàn");
		add(lbltBn);

	}

}
