package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class QL_NhanVien_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public QL_NhanVien_Panel() {
		
		JLabel lblNhnVin = new JLabel("Nhân Viên");
		add(lblNhnVin);

	}

}
