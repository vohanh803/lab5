package controller;

import java.util.List;

import DAO.DAO_MatHang;
import model.MatHang;

public class Controller_MatHang {

	public static List<MatHang> loadDatabase() {
		return DAO_MatHang.loadDatabase();
	}

	public static boolean checkMaMatHang(String check) {
		return DAO_MatHang.checkMaMatHang(check);
	}

	public static String taoMaMatHang() {
		return DAO_MatHang.taoKhoaChinh();
	}

	public static boolean themMH(String maMH, String tenMatHang, double gia,
			String donViTinh, int soLuong, String nhomHang, String ngay,
			String nhaCungCap) {
		
		MatHang matHang = new MatHang();

		matHang.setMaMatHang(maMH);
		matHang.setTenMatHang(tenMatHang);
		matHang.setGiaMatHang(gia);
		matHang.setDonViTinh(donViTinh);
		matHang.setSoLuong(soLuong);
		matHang.setNhomHang(nhomHang);
		matHang.setNgayNhap(ngay);
		matHang.setNhaCungCap(nhaCungCap);
		boolean checkAdd = DAO_MatHang.themMatHang(matHang);
		
		return checkAdd;
	}

	public static boolean xoaMatHang(MatHang matHang) {
		return DAO_MatHang.xoaMatHang(matHang);
	}
}
