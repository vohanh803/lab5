package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class QL_HoaDon_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public QL_HoaDon_Panel() {
		
		JLabel lblHon = new JLabel("Hoá Đơn");
		add(lblHon);

	}

}
