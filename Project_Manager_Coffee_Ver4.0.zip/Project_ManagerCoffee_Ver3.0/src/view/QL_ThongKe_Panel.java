package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class QL_ThongKe_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public QL_ThongKe_Panel() {
		
		JLabel lblThngK = new JLabel("Thống Kê");
		add(lblThngK);

	}

}
