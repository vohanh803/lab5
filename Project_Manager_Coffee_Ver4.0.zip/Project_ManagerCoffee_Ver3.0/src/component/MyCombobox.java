package component;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

public class MyCombobox {
	// list đơn vị tính
	private JComboBox<String> listDonViTinh;

	// list nhóm hàng
	private JComboBox<String> listNhomHang;

	// list nhà cung cấp
	private JComboBox<String> listNhaCungCap;

	// list giới tính
	private JComboBox<String> listGioiTinh;

	public JComboBox<String> getListDonViTinh() {
		DefaultComboBoxModel<String> tenDonViTinh = new DefaultComboBoxModel<String>();
		tenDonViTinh.addElement("");
		tenDonViTinh.addElement("Kg");
		tenDonViTinh.addElement("Gram");
		tenDonViTinh.addElement("Ly");
		this.listDonViTinh = new JComboBox<>(tenDonViTinh);
		this.listDonViTinh.setSelectedIndex(0);
		return listDonViTinh;
	}

	public JComboBox<String> getListNhomHang() {
		DefaultComboBoxModel<String> tenNhomHang = new DefaultComboBoxModel<String>();
		tenNhomHang.addElement("");
		tenNhomHang.addElement("Coffee");
		tenNhomHang.addElement("Sinh Tố");
		tenNhomHang.addElement("Thức Ăn");
		tenNhomHang.addElement("Kem");
		tenNhomHang.addElement("Thuốc Lá");

		this.listNhomHang = new JComboBox<String>(tenNhomHang);
		this.listNhomHang.setSelectedIndex(0);
		return listNhomHang;
	}

	public JComboBox<String> getListNhaCungCap() {
		DefaultComboBoxModel<String> nhaCungCap = new DefaultComboBoxModel<String>();
		nhaCungCap.addElement("");
		nhaCungCap.addElement("StarBuck Đức");
		nhaCungCap.addElement("Vinc Thiện");
		nhaCungCap.addElement("Coffee Lâm Đồng");
		nhaCungCap.addElement("Bảo Lộc Tea");

		this.listNhaCungCap = new JComboBox<String>(nhaCungCap);
		this.listNhaCungCap.setSelectedIndex(0);
		return listNhaCungCap;
	}

	public JComboBox<String> getListGioiTinh() {
		DefaultComboBoxModel<String> gioiTinh = new DefaultComboBoxModel<String>();
		gioiTinh.addElement("");
		gioiTinh.addElement("Nam");
		gioiTinh.addElement("Nữ");

		this.listGioiTinh = new JComboBox<String>(gioiTinh);
		this.listGioiTinh.setSelectedIndex(0);
		return listGioiTinh;
	}

}
