package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class TroGiup_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public TroGiup_Panel() {
		
		JLabel lblTrGip = new JLabel("Trợ Giúp");
		add(lblTrGip);

	}

}
