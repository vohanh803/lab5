package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class ThongTin_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public ThongTin_Panel() {
		
		JLabel lblThngTin = new JLabel("Thông Tin");
		add(lblThngTin);

	}

}
