package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class GioiThieu_Panel extends JPanel {

	/**
	 * Create the panel.
	 */
	public GioiThieu_Panel() {
		
		JLabel lblGiiThiu = new JLabel("Giới Thiệu");
		add(lblGiiThiu);

	}

}
