package view;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class QL_TongTien extends JPanel {

	/**
	 * Create the panel.
	 */
	public QL_TongTien() {
		
		JLabel lblTngTin = new JLabel("Tổng tiền");
		add(lblTngTin);

	}

}
